var AssetMng = cc.Class({
    extends: cc.Component,

    properties: {
        texBust: cc.SpriteFrame,
        texCardInfo: cc.SpriteFrame,
        texCountdown: cc.SpriteFrame,
        texBetCountdown: cc.SpriteFrame,
        playerPhotos: [cc.SpriteFrame]
    }
});
