## AutoRemoveParticle 使用说明

1. 创建一个粒子对象
2. 选中粒子对象，在ParticleSystem中勾选Auto Remove On Finish.
（勾选以后粒子会在播放结束后自动销毁自身）
