## Sliced Sprite 使用说明

1. 场景正中应该显示一个 UI 面板图像
2. Sprite 组件里的 Type 属性应设为 Sliced，这时 use original size 是取消勾选状态
3. 选中 use original size, 图像尺寸会恢复到贴图原始尺寸
4. 再次修改 size 属性，可以看到图像无损拉伸
5. 可以选中 Scene 面板左上角第四个操作选项，激活 Rect Gizmo，然后拖拽四个顶点，或四条边来修改图像的尺寸和位置
6. 点击 Sprite 属性最右边的 Editor 按钮，可以打开 Sprite Editor 编辑 Sprite 的切分方式