cc.Class({
    extends: cc.Component,

    properties: {
        power: 10
    },

    getPower: function() {
        return this.power;
    }
});
